#Program 7
n=int(input("How many values do you wanna enter: "))
print ("Enter")
li=[]
for i in range(0,n):
    li.append(input())
val=input("Enter the value: ")
flag=0
for x in li:
    if x==val:
        flag=1
        break
if flag==1:
    print("True")
else:
    print("False")
