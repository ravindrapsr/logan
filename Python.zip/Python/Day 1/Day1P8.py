#Program 8
n1=int(input("How many values do you wanna enter in first list: "))
print ("Enter")
l1=[]
for i in range(0,n1):
    l1.append(input())
n2=int(input("How many values do you wanna enter in second list: "))
print ("Enter")
l2=[]
for i in range(0,n2):
    l2.append(input())
flag=0
for x in l1:
    for y in l2:
        if x==y:
            flag=1
            break
if flag==1:
    print("True")
else:
    print("False")
