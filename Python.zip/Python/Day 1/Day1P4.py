#Program 4
firstname=input("Enter Your First Name ")
lastname=input("Enter Your Last Name ")
wholename=firstname+"."+lastname
print (wholename)
