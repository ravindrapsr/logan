#Program 9
n1=int(input("How many values do you wanna enter in the list: "))
print ("Enter")
l1=[]
for i in range(0,n1):
    l1.append(int(input()))
for x in l1:
    for i in range(0,x):
        print("*",end="")
    print("\n")
