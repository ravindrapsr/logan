#Program 6
li=[]
n=int(input("How many numbers do you wanna enter: "))
for i in range(0,n):
    x=int(input())
    li.append(x)
add=0
mul=1
for x in li:
    add+=x
for y in li:
    mul*=y
print(add,mul,sep='\n')
