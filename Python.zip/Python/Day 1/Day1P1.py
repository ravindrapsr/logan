#Program 1
name=input("Enter Your Name :")
print ("Hello,",name)
