#Program 2
a=int(input("Enter First No :"))
b=int(input("Enter Second No :"))
if a+b<0:
    print ("Negative")
else:
    print ("Positive")
