#Program 3
s=input("Enter No. ")
while(s.isnumeric()!=True):
    s=input("Please Enter a correct No. ")
print ("Correct!")
