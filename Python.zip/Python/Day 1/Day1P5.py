#Program 5
s=input("Enter a String: ")
f=s.swapcase()
print (f)
