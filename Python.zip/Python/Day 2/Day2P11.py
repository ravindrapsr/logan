import Ravi.mathematics

l1=[1,2,3,4]
l2=[5,6,7,8,9,10]
la=Ravi.mathematics.Add(l1,l2)
ls=Ravi.mathematics.Sub(l1,l2)
lso1=Ravi.mathematics.Sort_the_values(la)
lso2=Ravi.mathematics.Sort_the_values(ls)
lm1=Ravi.mathematics.Max(lso1)
lm2=Ravi.mathematics.Max(lso2)
print (la,ls,lso1,lso2,lm1,lm2)
