#program 3
n=int(input("No. of words :"))
print ("Enter")
li=[]
for i in range(n):
    li.append(input())
di={}
for s in li:
    di[s]=len(s)
print(di)
