#Program 1

def generate_n_chars(n,c):
    ch=""
    for i in range(n):
        ch+=c
    return ch

print(generate_n_chars(5,'x'))
