#Program 8

def translate(st):
    words=st.split(" ")
    n=len(words)
    li=[]
    for i in range(n):
        try:
            li.append(dnry[words[i]])
        except:
            li.append(words[i])
    return li

dnry={"merry":"god","christmas":"jul","and":"och","happy":"gott","new":"nytt","year":"ar"}
st=input("Enter an English sentence : ")
li=translate(st)
print (li)
