from mathematics import *
l1=[1,2,3]
l2=[4,5,7,6]
la=Add(l1,l2)
ls=Sub(l1,l2)
lso1=Sort_the_values(la)
lso2=Sort_the_values(ls)
lm1=Max(lso1)
lm2=Max(lso2)
print (la,ls,lso1,lso2,lm1,lm2)
