#Program 4
n=int(input("How many words :"))
li=[]
for i in range(n):
    li.append(len(input()))
find_longest_word=lambda li:max(li)
print(find_longest_word(li))
