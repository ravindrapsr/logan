#Program 7
import re
st=input("Enter a string :")
for i in range(10):
    st=st.replace(str(i),"")
st=re.sub(r"[^\w\s]","",st)
st=st.replace(" ","")
st=st.replace("[~`!@#$%^&*()_-+=]","")
st=st.lower()
word_set=set()
for i in st:
    word_set.add(i)
if len(word_set)==26:
    print ("Pangram")
else:
    print ("Not Pangram")
