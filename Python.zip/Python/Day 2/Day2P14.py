import math
from math import *
print("Only using methods of math as \"NumPy\" is not installed on this system\n\'math\' methods\n")
print(help(math))
print("\n\nSome Examples\n\n")

print("Math:\n\nFactorial(100) :{0}\nSquare Root(9801): {1}\nSin(90) : {2}".format(factorial(100),sqrt(9801),sin(90)))
