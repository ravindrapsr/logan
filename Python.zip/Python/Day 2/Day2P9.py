#Program 9

st=input("Enter a String : ")
di={}
for i in st:
    try:
        di[i]=di.get(i)+1
    except:
        di[i]=int(1)
print (di)
