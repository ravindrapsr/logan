import Date
from datetime import date
class UserDate:
    today=date.today()
    d=Date.Date(today.day,today.month,today.year)
    d.printDate()
