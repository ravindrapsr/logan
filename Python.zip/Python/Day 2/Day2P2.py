#Program 2
def max_in_list(*p):
    return max(p)

print(max_in_list(14,25))
print(max_in_list(14))
print(max_in_list(14,25,12))
print(max_in_list(14,25,56145))
print(max_in_list(14,25,1541,1552.0,54))
print(max_in_list(14,25,250,144,78,9546,454))
