
public class Personal {
	
	private String name;
	private int age;
	private char sex;
	private String addr;
	private String father;
	private String mother;	
	public Personal(String name,int age,char sex,String addr,String father,String mother)
	{
		this.name=name;
		this.age=age;
		this.sex=sex;
		this.addr=addr;
		this.father=father;
		this.mother=mother;
	}
	public String toString()
	{
		return "Name of the student is: "+this.name+"\nAge="+this.age+"\nStudent is "+this.sex+"\nAddress of the student is "+this.addr+"\nFather's Nam: Mr."+this.father+"\nMother's Name is: Mrs."+this.mother;
	}
}
