
public class Main_Class {

	public static void main(String args[])
	{
		Personal p=new Personal("Adam",16,'M',"Bangalore","JOHN","MARY");
		Educational e=new Educational("01234",679,95);
		Staff s=new Staff("DR Rajaram","Faculty","Professor");
		System.out.println("          STUDENT PERSONAL DETAILS\n"+p.toString()+"\n\n          STUDENT EDUCATIONAL DETAILS\n"+e.toString()+"\n\n            STAFF DETAILS\n"+s.toString());
	}
}
