
public class Staff {
	
	private String name;
	private String designation;
	private String position;
	
	public Staff(String name,String designation,String position)
	{
		this.name=name;
		this.designation=designation;
		this.position=position;
	}
	
	public String toString()
	{
		return "Name of the Member:"+this.name+"\nDesignation="+this.designation+"\nHis Position :"+this.position;
	}

}
