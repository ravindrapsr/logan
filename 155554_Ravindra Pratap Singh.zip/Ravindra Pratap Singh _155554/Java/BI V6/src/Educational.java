
public class Educational {

	private String roll;
	private float avg_marks;
	private float att;
	
	public Educational(String roll,float avg_marks,float att)
	{
		this.roll=roll;
		this.avg_marks=avg_marks;
		this.att=att;
	}
	public String toString()
	{
		return "Roll no of the student "+this.roll+"\nAverage of Marks of student="+this.avg_marks+"\nAttendance of student"+this.att+"%";
	}
}
