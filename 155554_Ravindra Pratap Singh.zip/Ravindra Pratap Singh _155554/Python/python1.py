words=[]
print ("Enter the element into a list:")
words=input().split()
final=[]
count=0
b=input("Enter word to remove: ")
n=int(input("Enter the occurrence to remove: "))
for i in words:
    if(i==b):
        count=count+1
        if(count!=n):
            final.append(i)
    else:
        final.append(i)
if(count==0):
    print("Item not found ")
else: 
    print("Updated list is: ",final)
